import React, { Component } from 'react';
import './App.css';

class App extends Component {
  state = {
    list: ["Dhaniya", "Aalo", "Timatar", "Podina"],
    inputText: '',
    searchInput: '',
    searchedList: [],
    editMode: false
  }

  addTodo() {
    const { list, inputText } = this.state

    list.push(inputText)

    this.setState({
      list,
      inputText: ''
    })
  }

  updateText(e) {
    this.setState({
      inputText: e.target.value
    })
  }

  deleteItem(index) {
    const { list } = this.state

    list.splice(index, 1)
    this.setState({
      list
    })
  }

  onSearchText(e) {
    const text = e.target.value
    const { list } = this.state

    const searchedList = list.filter(item => {
      return item.toLowerCase().indexOf(text) !== -1
    })

    this.setState({
      searchInput: text,
      searchedList
    })
  }

  editItem(index) {
    this.setState({
      editMode: true,
      editIndex: index
    })
  }

  updateTodo() {
    const { list, editIndex, inputText } = this.state

    list[editIndex] = inputText

    this.setState({
      list,
      editMode: false,
      editIndex: null
    })
  }

  render() {
    const { list, inputText, searchInput, searchedList, editMode } = this.state
    const loopList = searchInput ? searchedList : list

    return (
      <div className="App">
        <header className="App-header">
          <input
            placeholder="Search here..."
            onChange={this.onSearchText.bind(this)}
            value={searchInput}
          />

          <h1>TODO LIST</h1>

          <br />
          <input
            placeholder="Type any todo here"
            onChange={this.updateText.bind(this)}
            value={inputText}
          />
          {editMode ?
            <button onClick={this.updateTodo.bind(this)}>Update</button>
            :
            <button onClick={this.addTodo.bind(this)}>Add</button>
          }

          <br />

          {loopList.map((item, index) => {
            return <p>{item}
              <button onClick={this.editItem.bind(this, index)}>Edit</button>
              <button onClick={this.deleteItem.bind(this, index)}>Delete</button>
            </p>
          })}
        </header>
      </div>
    );
  }
}

export default App;

// class App extends Component {

//   something () {
//     this.setState({
//       text: "hello world"
//     })
//   }

//   render() {
//     return (
//       <div className="App">
//         <header className="App-header">
//           <button onClick={() => this.something()}>
//             Click me
//           </button>
//         </header>
//       </div>
//     );
//   }
// }

// export default App;

/*
Her Function ka apna "this" hota hain
LEKIN
Function ke ander Component ka "this" milne
ki 3 soorten hain
1) Ya to us function ko arrow function banado
E.g.
something = () => {
  this.setState({})
}

2) Ya to usko call karte waqt `.bind(this)`
kardo
E.g.
onClick={this.something.bind(this)}

3) Ya to usko call karte waqt arrow function
banado
E.g.
onClick={() => this.something()}


*/
